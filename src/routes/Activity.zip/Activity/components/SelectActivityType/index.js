import SelectActivityType from './SelectActivityType'

export default SelectActivityType
