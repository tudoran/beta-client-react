import ActivityFooter from './ActivityFooter'

export default ActivityFooter
