import Activity from './Activity'

export default Activity
