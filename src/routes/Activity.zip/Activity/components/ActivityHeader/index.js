import ActivityHeader from './ActivityHeader'

export default ActivityHeader
