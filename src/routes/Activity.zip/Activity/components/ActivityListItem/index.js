import ActivityListItem from './ActivityListItem'

export default ActivityListItem
