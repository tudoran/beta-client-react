import ActivityList from './ActivityList'

export default ActivityList
