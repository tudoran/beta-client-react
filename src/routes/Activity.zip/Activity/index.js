import ActivityContainer from './containers/ActivityContainer'

export default ActivityContainer
